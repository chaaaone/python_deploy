from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings
from .views import search_news


urlpatterns = [
    path('list/', views.slider, name='list-news'),
    path('detail/<int:slider_id>/', views.news_detail, name='news_detail'),
    path('search/', search_news, name='search_result'),

]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static('/slider_image/', document_root=settings.SLIDER_IMAGE_ROOT)
