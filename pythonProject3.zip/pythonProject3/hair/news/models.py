

# Create your models here.
from django.db import models


class Slider(models.Model):
    title = models.TextField(max_length=100, blank=False)
    description = models.TextField(blank=False)
    slider_image = models.ImageField(upload_to='slider_image/', blank=False)

    def __str__(self):
        return self.title
