

# Register your models here.
from django.contrib import admin

from .models import Slider
admin.site.register(Slider)




# Register your models here.
