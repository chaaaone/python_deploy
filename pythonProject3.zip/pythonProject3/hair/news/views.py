
from .models import Slider
from django.shortcuts import get_object_or_404
from django.utils.translation import activate
from django.shortcuts import render
from django.db.models import Q


def slider(request):
    if request.method == 'POST':
        language_code = request.POST.get('language')
        activate(language_code)
    sliders = Slider.objects.all()

    context = {
        'sliders': sliders,

    }

    return render(request, 'slider.html', context)


def search_news(request):
    query = request.GET.get('q')

    if query:
        results = Slider.objects.filter(
            Q(title_am__icontains=query) | Q(description_am__icontains=query) | Q(title_en__icontains=query) | Q(description_en__icontains=query) | Q(title_fr__icontains=query) | Q(description_fr__icontains=query)
        )
    else:
        results = []

    return render(request, 'search_result.html', {'results': results})
   # print(results.query)


def news_detail(request, slider_id):
    sliders = get_object_or_404(Slider, id=slider_id)
    context = {'slider': sliders}
    return render(request, 'index.html', context)





