app_name = 'news'
