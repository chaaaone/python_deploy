from django.urls import path
from .views import home_view
from product_list.views import product_list, product_detail, generate_thumbnail, add_to_cart,cart_view, update_cart, remove_from_cart, checkout
from news.views import slider, news_detail
from blog.views import blog_list, post_detail
from django.conf.urls.static import static
from django.conf import settings
import sys
from page_management.views import about, contact, faqs_page, service
sys.path.append('hair')

urlpatterns = [
    path('', home_view, name='home'),
    path('product-list/', product_list, name='product_list'),
    path('list/', slider, name='news-list'),
    path('blog/', blog_list, name='blog'),
    path('list', slider, name="home"),
    path('product_list/', product_list, name='product_listview'),
    path('thumbnail/', generate_thumbnail, name='thumb_list'),
    path('product/<int:product_id>/', product_detail, name='product_detail'),
    path('detail/<int:slider_id>/', news_detail, name='news_detail'),
    path('blog/', blog_list, name='blog'),
    path('blog_detail/<slug:slug>/', post_detail, name='post_detail'),
    path('cart/<int:product_id>/', cart_view, name='cart'),
    path('update_cart/<int:product_id>/', update_cart, name='update_cart'),
    path('remove_from_cart/<int:product_id>/', remove_from_cart, name='remove_cart'),
    path('checkout/<int:product_id>/', checkout, name='checkout'),
    path('cart/', cart_view, name='cart'),
    path('about/', about, name='about_us'),
    path('contact/', contact, name='contact_us'),
    path('faq/', faqs_page, name='faq_ask'),
    path('service/', service, name='service_list'),

]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static('/thumbnail/', document_root=settings.THUMBNAIL_ROOT)
    urlpatterns += static('/slider_image/', document_root=settings.SLIDER_IMAGE_ROOT)
