from django.shortcuts import render
from news.models import Slider
from product_list.models import Product
from blog.models import Post
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


def home_view(request):
    # Get the Slider objects
    sliders = Slider.objects.all()

    # Get the Product objects and paginate them
    product_all = Product.objects.all().order_by('id')
    product_paginator = Paginator(product_all, 6)  # Show 4 products per page
    product_page = request.GET.get('product_page', 1)
    try:
        product_page_obj = product_paginator.page(product_page)
    except PageNotAnInteger:
        product_page_obj = product_paginator.page(1)
    except EmptyPage:
        product_page_obj = product_paginator.page(product_paginator.num_pages)

    # Get the Post objects and paginate them
    posts = Post.objects.all()
    posts_paginator = Paginator(posts, 4)  # Show 3 posts per page
    posts_page = request.GET.get('posts_page', 1)
    try:
        posts_page_obj = posts_paginator.page(posts_page)
    except PageNotAnInteger:
        posts_page_obj = posts_paginator.page(1)
    except EmptyPage:
        posts_page_obj = posts_paginator.page(posts_paginator.num_pages)

    context = {
        'sliders': sliders,
        'product_all': product_page_obj,
        'posts': posts_page_obj,
    }
    return render(request, 'base.html', context)