from django.contrib.auth.decorators import login_required
from django.urls import reverse_lazy
from django.views import generic
from django.shortcuts import render, redirect
from .models import Post
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, login as auth_login, logout

# Create your views here.

# Decorator to show the profile that requires authentication
@login_required
def user_profile(request):
    return render(request, 'profile.html')

def custom_login(request):
    return render(request, 'registration/login.html')

def fetch_posts(request):
    posts = Post.objects.all()
    return render(request, 'account.html', {'posts': posts})

class SignUpView(generic.CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy("login")
    template_name = ("registration/signup.html")

def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                auth_login(request, user)  # Use auth_login instead of login
                return redirect('home')
    else:
        form = AuthenticationForm()
        return render(request, 'registration/login.html', {'form': form})

def user_logout(request):
    logout(request)
    return redirect('home')
# Create your views here.
