const slides = document.querySelectorAll('.slide');
let currentSlide = 0;
let intervalId;

function showSlide(slideIndex) {
  slides.forEach((slide) => {
    slide.classList.remove('active');
  });
  slides[slideIndex].classList.add('active');
}

function nextSlide() {
  currentSlide++;
  if (currentSlide >= slides.length) {
    currentSlide = 0;
  }
  showSlide(currentSlide);
}

function startSlideShow() {
  intervalId = setInterval(nextSlide, 5000);
}

function pauseSlideShow() {
  clearInterval(intervalId);
}

// Initialize the first slide
showSlide(currentSlide);

// Start the slide show
startSlideShow();

// Add event listeners to pause and resume the slide show
slides.forEach((slide) => {
  slide.addEventListener('mouseenter', pauseSlideShow);
  slide.addEventListener('mouseleave', startSlideShow);
});

// Read more/less functionality
$(document).ready(function() {
  $('.read-more').click(function(e) {
    e.preventDefault();
    $(this).prev('p').toggleClass('show-full-text');
    $(this).text(function(i, text) {
      return text === 'Read More' ? 'Read Less' : 'Read More';
    });
  });
});

// Language switcher
const languageSwitcher = document.querySelector('.language-switcher');
const languageLinks = languageSwitcher.querySelectorAll('a');

languageLinks.forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const language = link.textContent;
    // code to switch the website's language
  });
});