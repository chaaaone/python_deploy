from django.conf.urls.static import static
from django.urls import path
from django.conf import settings
from . import views


app_name = "product_list"
urlpatterns = [

    path('product_list/', views.product_list, name='product_listview'),
    path('thumbnail/', views.generate_thumbnail, name='thumb_list'),
    path('product/<int:product_id>/', views.product_detail, name='product_detail'),
    path('cart/<int:product_id>/', views.cart_view, name='cart'),
    path('update_cart/<int:product_id>/', views.update_cart, name='update_cart'),
    path('remove_from_cart/<int:product_id>/', views.remove_from_cart, name='remove_cart'),
    path('checkout/<int:product_id>/', views.checkout, name='checkout'),

    ]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += static('/thumbnail/', document_root=settings.THUMBNAIL_ROOT)






