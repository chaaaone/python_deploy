from audioop import reverse

from PIL import Image
from .models import Cart
from .models import Product
from django.core.paginator import Paginator
from django.shortcuts import render, redirect,  get_object_or_404
import stripe


def generate_thumbnail(image):
    img = Image.open(image.path)
    max_size = (100, 100)  # Set the maximum size for the thumbnail
    img.thumbnail(max_size)
    thumbnail_path = image.path.replace('uploads/', 'thumbnail/')
    img.save(thumbnail_path)


def product_list(request):
    all_products = Product.objects.all().order_by('id')  # Order by ID for example
    paginator = Paginator(all_products, 6)  # 3 products per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'product_page': page_obj,
    }
    return render(request, 'product_list_page.html', context)


def product_detail(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    context = {
        'product': product,
    }
    return render(request, 'product_detail.html', context)


def add_to_cart(request, product_id):
    if request.user.is_authenticated:
        product = get_object_or_404(Product, id=product_id)
    cart_item, created = Cart.objects.get_or_create(
        user=request.user,
        product=product,
        defaults={'quantity': 1}
    )
    if not created:
        cart_item.quantity += 1
        cart_item.save()
    return redirect('cart')


def cart(request):
    cart_items = Cart.objects.filter(user=request.user)
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    context = {
        'cart_items': cart_items,
        'total_price': total_price,
    }
    return render(request, 'cart.html', context)


def update_cart(request, cart_item_id):
    cart_item = get_object_or_404(Cart, id=cart_item_id, user=request.user)
    if request.method == 'POST':
        quantity = int(request.POST.get('quantity'))
        cart_item.quantity = quantity
        cart_item.save()
    return redirect('cart')


def remove_from_cart(request, cart_item_id):
    cart_item = get_object_or_404(Cart, id=cart_item_id, user=request.user)
    cart_item.delete()
    return redirect('cart')


stripe.api_key = 'your_stripe_secret_key'


def checkout(request):
    cart_items = Cart.objects.filter(user=request.user)
    total_price = sum(item.product.price * item.quantity for item in cart_items)

    if request.method == 'POST':
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': item.product.name,
                    },
                    'unit_amount': int(item.product.price * 100),
                },
                'quantity': item.quantity,
            } for item in cart_items],
            mode='payment',
            success_url=request.build_absolute_uri(reverse('payment_success')),
            cancel_url=request.build_absolute_uri(reverse('payment_cancel')),
        )
        return redirect(checkout_session.url)

    context = {
        'cart_items': cart_items,
        'total_price': total_price,
    }
    return render(request, 'checkout.html', context)


def payment_success(request):
    # Handle successful payment
    Cart.objects.filter(user=request.user).delete()
    return render(request, 'payment_success.html')


def payment_cancel(request):
    # Handle canceled payment
    return render(request, 'payment_cancel.html')


def cart_view(request):
    if request.user.is_authenticated:
        cart_items = Cart.objects.filter(user=request.user)
        # Render the cart template with the cart items
        return render(request, 'cart.html', {'cart_items': cart_items})
    else:
        # Handle anonymous user's cart from the session
        carts = request.session.get('cart', {})
        # Render the cart template with the session-based cart items
        return render(request, 'cart.html', {'cart_items': carts.values()})


# custom_filters.py
from django import template

register = template.Library()


@register.filter
def mul(value, arg):
    return value * arg