import logging

logger = logging.getLogger(__name__)


class ErrorHandlingMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        try:
            response = self.get_response(request)
        except Exception as e:
            # Log the exception
            logger.exception("An error occurred during the request-response cycle:")

            # You can choose to customize the error handling behavior here
            # For example, you can render a custom error page or return a specific response

            # Reraise the exception to allow Django's default exception handling
            raise

        return response