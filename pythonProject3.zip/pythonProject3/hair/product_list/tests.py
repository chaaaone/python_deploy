
import pytest
from PIL import Image
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import RequestFactory
from hair.product_list.models import Product
from hair.product_list.views import generate_thumbnail, product_list, product_detail


@pytest.fixture
def create_product():
    def _create_product(title):
        return Product.objects.create(title=title)
    return _create_product

@pytest.fixture
def create_image_file(tmpdir):
    def _create_image_file(filename, tmpdir, size=(500, 500), color=(256, 0, 0)):
        image = Image.new("RGB", size, color)
        file_path = tmpdir.join(filename)
        image.save(str(file_path), "JPEG")
        return SimpleUploadedFile(name=filename, content=open(str(file_path), "rb").read(), content_type="image/jpeg")
    return _create_image_file

@pytest.mark.django_db
def test_generate_thumbnail(create_image_file, tmpdir):
    image_file = create_image_file("test.jpg")
    thumbnail_path = str(tmpdir.join("thumbnail.jpg"))
    generate_thumbnail(image_file)
    assert tmpdir.join("thumbnail").check()  # Check if the thumbnail was created

def test_product_list(create_product):
    request = RequestFactory().get('/')
    products = [
        create_product("Product 1"),
        create_product("Product 2"),
        create_product("Product 3"),
    ]
    response = product_list(request)
    assert response.status_code == 200
    assert len(response.context['page']) == 3  # Check if all products are passed to the context

def test_product_detail(create_product):
    product = create_product("Test Product")
    request = RequestFactory().get('/')
    response = product_detail(request, product.id)
    assert response.status_code == 200
    assert response.context['product'].id == product.id  # Check if the correct product is passed to the context
# Create your tests here.
