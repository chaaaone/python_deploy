from django.shortcuts import render
from django.utils.translation import activate
from django.utils.translation import gettext as _


def home(request):
    activate(request.LANGUAGE_CODE)  # Activate the current language
    title = _('Welcome to My Website')
    description = _('This is the description of my website.')
    menu_items = [_('Home'), _('About Us'), _('Contact'), _('Services')]

    context = {
        'title': title,
        'description': description,
        'menu_items': menu_items
    }

    return render(request, 'translation.html', context)


