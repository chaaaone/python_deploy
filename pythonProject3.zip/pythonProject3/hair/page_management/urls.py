from django.urls import path

from . import views

urlpatterns = [
    path('about/', views.about, name='about_us'),
    path('contact/', views.contact, name='contact'),
    path('privacy/', views.privacy_page, name='privacy'),
    path('faq/', views.faqs_page, name='faq'),
    path('blog/', views.faqs_page, name='blog'),



]
