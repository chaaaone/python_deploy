

# Create your views here.
from django.shortcuts import render
# Create your views here.


def about(request):
    return render(request, 'about.html')


def contact(request):
    return render(request, 'contact.html')


def privacy_page(request):
    return render(request, 'privacy.html')

def faqs_page(request):
    return render(request, 'faq.html')

def blog_page(request):
    return render(request, 'blog.html')
    # Redirect back to the main page


def service(request):
    return render(request, 'services.html')