from django.shortcuts import render, get_object_or_404, redirect
from .models import Post, Tag
from .forms import CommentForm


def blog_list(request):
    post = Post.objects.filter(published=True).order_by('-publish_date').first()
    context = {
        'post': post
    }
    return render(request, 'blog.html', context)


def blog_detail(request, slug):
    post = get_object_or_404(Post, slug=slug)
    context = {
        'post': post
    }
    return render(request, 'blog_detail.html', context)


def tag_list(request):
    tags = Tag.objects.all()
    context = {
        'tags': tags
    }
    return render(request, 'blog.html', context)


def tag_detail(request, name):
    tag = get_object_or_404(Tag, name=name)
    posts = tag.post_set.filter(published=True).order_by('-publish_date')
    context = {
        'tag': tag,
        'posts': posts
    }
    return render(request, 'tag_detail.html', context)
# Create your views here.


def post_detail(request, slug):
    post = get_object_or_404(Post, slug=slug)
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.post = post
            comment.save()
            return redirect('post_detail', slug=post.slug)
    else:
        form = CommentForm()
    return render(request, 'post_detail.html', {'post': post, 'form': form})
