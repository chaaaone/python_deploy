from django.urls import path
from . import views

urlpatterns = [
    path('blog/', views.blog_list, name='blog'),
    path('blog_detail/<slug:slug>/', views.post_detail, name='post_detail'),

]
