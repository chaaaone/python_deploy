from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from product_list.views import product_detail, generate_thumbnail, product_list, add_to_cart, cart_view
from blog.views import blog_list, post_detail
from home.views import home_view
from news.views import search_news, slider, news_detail
from page_management.views import about, contact, faqs_page, service

urlpatterns = [
    path('admin/', admin.site.urls),
    path('__debug__/', include('debug_toolbar.urls')),
    path('page/', include('page_management.urls')),
    path('user/', include('user_management.urls')),
    path('home/', include('home.urls')),
    path('', home_view, name='home'),
    path('list', slider, name="home"),
    path('product_list/', product_list, name='product_listview'),
    path('thumbnail/', generate_thumbnail, name='thumb_list'),
    path('product/<int:product_id>/', product_detail, name='product_detail'),
    path('detail/<int:slider_id>/', news_detail, name='news_detail'),
    path('blog/', blog_list, name='blog'),
    path('blog_detail/<slug:slug>/', post_detail, name='post_detail'),
    path('search/', search_news, name='search_result'),
    path('cart/<int:product_id>/', cart_view, name='cart'),
    path('about/', about, name='about_us'),
    path('contact/', contact, name='contact_us'),
    path('faq/', faqs_page, name='faq_ask'),
    path('service/', service, name='service_list'),

]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static('/thumbnail/', document_root=settings.THUMBNAIL_ROOT)
    urlpatterns += static('/slider_image/', document_root=settings.SLIDER_IMAGE_ROOT)
